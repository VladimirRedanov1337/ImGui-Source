//
// Created by rei on 12/18/23.
//

#include "menu.hpp"
#include "util/widgets.hpp"
#include "util/helpers.hpp"
#include "util/ryukoutils.hpp"
#include <thread>
#include <fonts/benzin.hpp>
#include <fonts/Roboto_Regular.h>
#include <fonts/sf_pro.h>
#include <fonts/font_awesome.h>
#include <fonts/fontz.hpp>
#include <imgui_wrapper/imgui_wrapper.hpp>
#include "imgui_internal.h"

namespace menu {
	static inline ImVec4 color_lerp(const ImVec4& a, const ImVec4& b, float t) { return ImVec4(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.z + (b.z - a.z) * t, a.w + (b.w - a.w) * t); }
	ImFont* logoFont;
    struct tab {
        std::string name;
        std::string icond;
        ImVec4 bgcolor = {0, 0, 0, 0};
        ImVec4 textcolor = {0, 0, 0, 0};
    };
    int selected_tab;
    std::vector<tab> tabs;

    inline float lerp(float a, float b, float f) {
        return std::clamp<float>(a + f * (b - a),a > b ? b : a,a > b ? a : b);
    }

    namespace features {
        auto child1(int tab) -> void {
            if (tab == 0) {
            	vars.child1n = ("Functions");
		static bool nigger;
		c_menu::checkbox("nigger", &nigger);
		static bool niggercolor; static ImVec4 niggercolorv;
		c_menu::colorcheckbox("niggercolor", &niggercolor, niggercolorv);
		static int slider_value;
		c_menu::slider_int("slider value", &slider_value, -5, 5);
		c_menu::button("button ex");
		static const char* vs[] = {"aaa", "bbb"};
		static int vc;
		c_menu::combo("comboex", &vc, vs, IM_ARRAYSIZE(vs));
            } else if (tab == 1) {
            	vars.child1n = ("ESP players");
            } else if (tab == 2) {
            	vars.child1n = ("Movement");
            } else if (tab == 3) {
            	vars.child1n = ("Profile");
            } else if (tab == 4) {
            	vars.child1n = ("Config");
            }
        }

        auto child2(int tab) -> void {
            if (tab == 0) {
            	vars.child2n = ("Aim");
            } else if (tab == 1) {
            	vars.child2n = ("Other");
            } else if (tab == 2) {
            	vars.child2n = ("Misc");
            } else if (tab == 3) {
            	vars.child2n = ("Menu");
                ImGui::ColorEdit3(("accent"), (float*) &vars.accent);
            } else if (tab == 4) {
            	vars.child2n = ("???");
            }
        }
    }

    auto init() -> void {
        tabs.push_back({("Combat"), "A"});
        tabs.push_back({("Visual"), "B"});
        tabs.push_back({("Game"), "C"});
        tabs.push_back({("Misc"), "D"});
        tabs.push_back({ICON_FA_GEAR, "E"});

        ImGui::GetStyle().Colors[ImGuiCol_WindowBg] = ImColor(28, 28, 30);
        ImGui::GetStyle().Colors[ImGuiCol_Border] = ImColor(36, 36, 38);
        ImGui::GetStyle().Colors[ImGuiCol_ChildBg] = ImColor(36, 36, 38);
        ImGui::GetStyle().Colors[ImGuiCol_Accent] = ImColor(255, 0, 0);
        ImGui::GetStyle().Colors[ImGuiCol_PopupBg] = ImColor(36, 36, 38);
        ImGui::GetStyle().Colors[ImGuiCol_FrameBg] = ImColor(36, 36, 38);
        ImGui::GetStyle().Colors[ImGuiCol_FrameBgHovered] = ImColor(36, 36, 38);
        ImGui::GetStyle().Colors[ImGuiCol_FrameBgActive] = ImColor(36, 36, 38);

        ImGui::GetStyle().WindowRounding = 8;
        ImGui::GetStyle().FrameRounding = 4;
        ImGui::GetStyle().ChildRounding = 6;
        ImGui::GetStyle().PopupRounding = 6;
        
        auto io = ImGui::GetIO();
     
        ImGui::GetStyle().ScaleAllSizes(1.5f*1.5);
        // Load Fonts
        static const ImWchar glyph_ranges[] =
                {
                        0x0020, 0x00FF, // Basic Latin + Latin Supplement
                        0x0400, 0x052F, // Cyrillic + Cyrillic Supplement
                        0x2DE0, 0x2DFF, // Cyrillic Extended-A
                        0xA640, 0xA69F, // Cyrillic Extended-B
                        0,
                };

        ImFontConfig font2_cfg;
        font2_cfg.SizePixels = 24.0f;
        font2_cfg.GlyphRanges = _imgui::getio().Fonts->GetGlyphRangesCyrillic();
        io.Fonts->AddFontFromMemoryTTF(medfont, sizeof medfont, 16*1.5);
        
        ImFontConfig font_cfg;
        font_cfg.MergeMode = true;
        font_cfg.GlyphMinAdvanceX = 24 * 2.f / 3.f;
        static const ImWchar icon_ranges[] = {ICON_MIN_FA, ICON_MAX_FA, 0x0};

        io.Fonts->AddFontFromMemoryCompressedBase85TTF(FontAwesome6_compressed_data_base85, 16*1.5 * 2.f / 3.f, &font_cfg, icon_ranges);

        logoFont = io.Fonts->AddFontFromMemoryTTF(heavyfont, sizeof heavyfont, 24*1.5);
    }

    auto render() -> void {
        {
            ImGui::GetStyle().Colors[ImGuiCol_Accent] = ImColor(255, 255, 255).Value;// here's vars.accent var but yeeee vars.accent;

            int glWidth = ImGui::GetIO().DisplaySize.x;
            int glHeight = ImGui::GetIO().DisplaySize.y;
            ImGui::PushStyleColor(ImGuiCol_WindowBg, ImColor(0, 0, 0, 0).Value);
            ImGui::PushStyleColor(ImGuiCol_Border, ImColor(0, 0, 0, 0).Value);
            ImGui::GetStyle().WindowMinSize = ImVec2(0, 0);
            ImGui::SetNextWindowPos(
                    ImVec2(glWidth / 2 - 100, glHeight - 60));
            ImGui::SetNextWindowSize(ImVec2(200, 50));
            ImGui::Begin(("##menuuuuu"), nullptr,
                         ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar |
                         ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoResize);
            if (ImGui::InvisibleButton(("##dbuitiin"), ImGui::GetWindowSize()))
                vars.opened = !vars.opened;
            ImGui::GetWindowDrawList()->AddRectFilled(
                    ImVec2(glWidth / 2 - 100, glHeight - 15),
                    ImVec2(glWidth / 2 + 100, glHeight - 10),
                    ImColor(255, 255, 255), 10);
            ImGui::End();
            ImGui::PopStyleColor(2);
            
            if (vars.opened) vars.main_alpha.update(1.f);
            else vars.main_alpha.update(0.f);

            auto style = ImGui::GetStyle();

            _imgui::push_style(ImGuiStyleVar_Alpha, vars.main_alpha.value);

            if (ImGui::GetStyle().Alpha > 0.01f) {
                const char* title_text = ("CLAWCLOUDS");
                const char* subtitle_text = ("Codename: superior");

                auto title_text_size = ImGui::CalcTextSize(title_text);
                auto subtitle_text_size = ImGui::CalcTextSize(subtitle_text);

                float offset = title_text_size.y;

                ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, {0,0});
                ImGui::SetNextWindowSize({700*1.5, 540*1.5});

                ImGui::Begin(("CLOUDCLAWCPPMENU"), nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoResize);

                {
                    ImGui::SetCursorPos({0, 0});

                    ImGui::PushStyleColor(ImGuiCol_ChildBg, {0, 0, 0, 0});
                    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 0);

                    ImGui::BeginChild(("##headerlayout"), {ImGui::GetWindowSize().x, 72*1.5}, true);

                    ImGui::PopStyleColor();
                    ImGui::PopStyleVar();

                    ImGui::SetCursorPos({offset - 1*1.5, offset - 2*1.5});

                    ImGui::PushFont(logoFont);
                    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(ImColor(235, 235, 244)));
                    ImGui::Text(title_text);
                    ImGui::PopStyleColor();
                    ImGui::PopFont();

                    ImGui::SetCursorPos({offset - 1*1.5, ImGui::GetCursorPos().y - 4*1.5 + 2*1.5});

                    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(ImColor(115, 115, 126)));
                    ImGui::Text(subtitle_text);
                    ImGui::PopStyleColor();

                    //tabs
                    {
                        const static ImVec2 tab_size = {72*1.5, 40*1.5};

                        ImGui::SetCursorPos({ImGui::GetWindowSize().x - (tab_size.x)*(tabs.size()) - 16*1.5, 16*1.5});

                        ImGui::PushStyleColor(ImGuiCol_Button, {0,0,0,0});
                        ImGui::PushStyleColor(ImGuiCol_ButtonActive, {0,0,0,0});
                        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, {0,0,0,0});

                        static animation_vec2 position(ImVec2(0, 0));

                        auto draw = ImGui::GetWindowDrawList();

                        ImVec2 cur2 = {ImGui::GetWindowPos().x + position.value.x + tab_size.x, ImGui::GetWindowPos().y + position.value.y + tab_size.y};

                        draw->AddRectFilled({ImGui::GetWindowPos().x + position.value.x, ImGui::GetWindowPos().y + position.value.y}, cur2, ImColor(34, 34, 36, int(255*ImGui::GetStyle().Alpha)), 6);
                        draw->AddRectFilled({ImGui::GetWindowPos().x + position.value.x + 8*1.5, ImGui::GetWindowPos().y + position.value.y + 40*1.5 + 13*1.5}, {cur2.x - 8*1.5, ImGui::GetWindowPos().y + position.value.y + 72*1.5}, ImColor(int(ImGui::GetStyleColorVec4(ImGuiCol_Accent).x*255), int(ImGui::GetStyleColorVec4(ImGuiCol_Accent).y*255), int(ImGui::GetStyleColorVec4(ImGuiCol_Accent).z*255), int(255*ImGui::GetStyle().Alpha)), 4*1.5);

                        for (int i = 0; i < tabs.size(); i++) {
                            tabs[i].textcolor = color_lerp(tabs[i].textcolor, (i == selected_tab) ? ImColor(int(ImGui::GetStyleColorVec4(ImGuiCol_Accent).x*255), int(ImGui::GetStyleColorVec4(ImGuiCol_Accent).y*255), int(ImGui::GetStyleColorVec4(ImGuiCol_Accent).z*255), int(ImGui::GetStyle().Alpha * 255)) : ImColor(115, 115, 126, int(ImGui::GetStyle().Alpha * 255)), ImGui::GetIO().DeltaTime * 6.f);
                            auto cur = ImGui::GetCursorScreenPos();
                            if (i == selected_tab) position.update(ImGui::GetCursorPos());
                            auto tab_text_size = ImGui::CalcTextSize(tabs[i].name.c_str());
                            auto ccur2 = {cur.x + tab_size.x, cur.y + tab_size.y};
                            draw->AddText({cur.x + tab_size.x / 2 - tab_text_size.x / 2, cur.y + tab_size.y / 2 - tab_text_size.y / 2}, ImColor(tabs[i].textcolor), tabs[i].name.c_str());
                            if (ImGui::InvisibleButton(tabs[i].name.c_str(), tab_size)) selected_tab = i;
                            ImGui::SameLine(0, 0);
                        }

                        ImGui::PopStyleColor(3);
                    }

                    ImGui::EndChild();

                    auto child_size = ImVec2(ImGui::GetContentRegionAvail().x / 2 - offset + 1*1.5 - ((offset - 1*1.4) / 2), ImGui::GetContentRegionAvail().y - offset + 4*1.5 - offset + 1*1.5);

                    ImGui::SetCursorPos({offset - 1*1.5, 72*1.5 + offset - 1*1.5});

                    ImGui::BeginChild(("##leftchild"), child_size, true);
                    {
                        ImGui::SetCursorPos({0, 0});
                        auto cur = ImGui::GetCursorScreenPos();
                        auto draw = ImGui::GetWindowDrawList();
                        draw->AddRectFilledMultiColor(cur, {cur.x + ImGui::GetWindowSize().x, cur.y + 38*1.5}, ImColor(ImGui::GetStyleColorVec4(ImGuiCol_Accent).x, ImGui::GetStyleColorVec4(ImGuiCol_Accent).y, ImGui::GetStyleColorVec4(ImGuiCol_Accent).z, 0.4f*ImGui::GetStyle().Alpha), ImColor(36, 36, 38, int(255*ImGui::GetStyle().Alpha)), ImColor(36, 36, 38, int(255*ImGui::GetStyle().Alpha)), ImColor(ImGui::GetStyleColorVec4(ImGuiCol_Accent).x, ImGui::GetStyleColorVec4(ImGuiCol_Accent).y, ImGui::GetStyleColorVec4(ImGuiCol_Accent).z, 0.4f*ImGui::GetStyle().Alpha));
                        draw->AddText({cur.x + 38*1.5/2 - ImGui::CalcTextSize(vars.child1n.c_str()).y / 2 + 4*1.5, cur.y + 38*1.5/2 - ImGui::CalcTextSize(vars.child1n.c_str()).y / 2}, ImColor(int(ImGui::GetStyleColorVec4(ImGuiCol_Accent).x*255), int(ImGui::GetStyleColorVec4(ImGuiCol_Accent).y*255), int(ImGui::GetStyleColorVec4(ImGuiCol_Accent).z*255), int(255*ImGui::GetStyle().Alpha)), vars.child1n.c_str());
                        {
                            ImGui::SetCursorPos({0, 38*1.5});
                            ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(offset - 1*1.5, offset - 1));
                            ImGui::PushStyleVar(ImGuiStyleVar_ItemInnerSpacing, ImVec2(8*1.5, offset - 1*1.5));
                            ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(offset - 1*1.5, offset - 1*1.5));
                            ImGui::BeginChild(vars.child1n.c_str(), ImGui::GetContentRegionAvail(), true);
                            {
                                features::child1(selected_tab);
                            }
                            ImGui::EndChild();
                            ImGui::PopStyleVar(3);
                        }
                    }
                    ImGui::EndChild();

                    ImGui::SameLine(0, offset - 1);

                    ImGui::BeginChild(("##rightchild"), child_size, (true));
                    {
                        ImGui::SetCursorPos({0, 0});
                        auto cur = ImGui::GetCursorScreenPos();
                        auto draw = ImGui::GetWindowDrawList();
                        draw->AddRectFilledMultiColor(cur, {cur.x + ImGui::GetWindowSize().x, cur.y + 38*1.5}, ImColor(ImGui::GetStyleColorVec4(ImGuiCol_Accent).x, ImGui::GetStyleColorVec4(ImGuiCol_Accent).y, ImGui::GetStyleColorVec4(ImGuiCol_Accent).z, 0.4f*ImGui::GetStyle().Alpha), ImColor(36, 36, 38, int(255*ImGui::GetStyle().Alpha)), ImColor(36, 36, 38, int(255*ImGui::GetStyle().Alpha)), ImColor(ImGui::GetStyleColorVec4(ImGuiCol_Accent).x, ImGui::GetStyleColorVec4(ImGuiCol_Accent).y, ImGui::GetStyleColorVec4(ImGuiCol_Accent).z, 0.4f*ImGui::GetStyle().Alpha));
                        draw->AddText({cur.x + 38*1.5/2 - ImGui::CalcTextSize(vars.child2n.c_str()).y / 2 + 4*1.5, cur.y + 38*1.5/2 - ImGui::CalcTextSize(vars.child2n.c_str()).y / 2}, ImColor(int(ImGui::GetStyleColorVec4(ImGuiCol_Accent).x*255), int(ImGui::GetStyleColorVec4(ImGuiCol_Accent).y*255), int(ImGui::GetStyleColorVec4(ImGuiCol_Accent).z*255), int(255*ImGui::GetStyle().Alpha)), vars.child2n.c_str());
                        {
                            ImGui::SetCursorPos({0, 38*1.5});
                            ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(offset - 1*1.5, offset - 1*1.5));
                            ImGui::PushStyleVar(ImGuiStyleVar_ItemInnerSpacing, ImVec2(8*1.5, offset - 1*1.5));
                            ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(offset - 1*1.5, offset - 1*1.5));
                            ImGui::BeginChild(vars.child2n.c_str(), ImGui::GetContentRegionAvail(), true);
                            {
                                features::child2(selected_tab);
                            }
                            ImGui::EndChild();
                            ImGui::PopStyleVar(3);
                        }
                    }
                    ImGui::EndChild();

                    ImGui::End();
                }

                ImGui::PopStyleVar();
            }

            ImGui::PopStyleVar();
        }
    }
}