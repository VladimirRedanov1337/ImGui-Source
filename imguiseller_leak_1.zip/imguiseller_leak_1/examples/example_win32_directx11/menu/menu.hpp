//
// Created by rei on 12/18/23.
//

#ifndef MENU_HPP
#define MENU_HPP

#include "imgui.h"
#include <string>
#include "util/ryukoutils.hpp"

namespace menu {
    struct _vars {
        bool opened;
        ImVec4 accent = {1, 0, 0, 1};
        ImGuiStyle original_style;
        std::string child1n = ("claw");
        std::string child2n = ("clouds");
        animation main_alpha;
    };
    
    inline _vars vars;

    auto init() -> void;
    auto render() -> void;
}

#endif //MENU_HPP
