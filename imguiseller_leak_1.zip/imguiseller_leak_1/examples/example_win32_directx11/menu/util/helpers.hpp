//
// Created by rei on 12/19/23.
//

#ifndef HELPERS_HPP
#define HELPERS_HPP

#include "imgui_internal.h"

namespace c_helpers {
    ImVec2 get_available_region();
    void scale_all_sizes(ImGuiStyle& shit, float scale_factor, ImGuiStyle source_style);
}

#endif //HELPERS_HPP
