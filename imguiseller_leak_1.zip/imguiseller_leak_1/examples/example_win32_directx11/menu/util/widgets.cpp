//
// Created by rei on 12/19/23.
//

#include "widgets.hpp"
#include "helpers.hpp"
#include "imgui.h"
#include "imgui_internal.h"

using namespace ImGui;
using namespace std;

static inline ImVec2  operator*(const ImVec2& lhs, const float rhs) { return ImVec2(lhs.x * rhs, lhs.y * rhs); }
static inline ImVec2  operator/(const ImVec2& lhs, const float rhs) { return ImVec2(lhs.x / rhs, lhs.y / rhs); }
static inline ImVec2  operator+(const ImVec2& lhs, const float rhs) { return ImVec2(lhs.x + rhs, lhs.y + rhs); }
static inline ImVec2  operator+(const ImVec2& lhs, const ImVec2& rhs) { return ImVec2(lhs.x + rhs.x, lhs.y + rhs.y); }
static inline ImVec2  operator-(const ImVec2& lhs, const ImVec2& rhs) { return ImVec2(lhs.x - rhs.x, lhs.y - rhs.y); }
static inline ImVec2  operator-(const ImVec2& lhs, const float rhs) { return ImVec2(lhs.x - rhs, lhs.y - rhs); }
static inline ImVec2  operator*(const ImVec2& lhs, const ImVec2& rhs) { return ImVec2(lhs.x * rhs.x, lhs.y * rhs.y); }
static inline ImVec2  operator/(const ImVec2& lhs, const ImVec2& rhs) { return ImVec2(lhs.x / rhs.x, lhs.y / rhs.y); }
static inline ImVec2& operator*=(ImVec2& lhs, const float rhs) { lhs.x *= rhs; lhs.y *= rhs; return lhs; }
static inline ImVec2& operator/=(ImVec2& lhs, const float rhs) { lhs.x /= rhs; lhs.y /= rhs; return lhs; }
static inline ImVec2& operator+=(ImVec2& lhs, const ImVec2& rhs) { lhs.x += rhs.x; lhs.y += rhs.y; return lhs; }
static inline ImVec2& operator-=(ImVec2& lhs, const ImVec2& rhs) { lhs.x -= rhs.x; lhs.y -= rhs.y; return lhs; }
static inline ImVec2& operator*=(ImVec2& lhs, const ImVec2& rhs) { lhs.x *= rhs.x; lhs.y *= rhs.y; return lhs; }
static inline ImVec2& operator/=(ImVec2& lhs, const ImVec2& rhs) { lhs.x /= rhs.x; lhs.y /= rhs.y; return lhs; }
static inline ImVec4  operator+(const ImVec4& lhs, const ImVec4& rhs) { return ImVec4(lhs.x + rhs.x, lhs.y + rhs.y, lhs.z + rhs.z, lhs.w + rhs.w); }
static inline ImVec4  operator-(const ImVec4& lhs, const ImVec4& rhs) { return ImVec4(lhs.x - rhs.x, lhs.y - rhs.y, lhs.z - rhs.z, lhs.w - rhs.w); }
static inline ImVec4  operator*(const ImVec4& lhs, const ImVec4& rhs) { return ImVec4(lhs.x * rhs.x, lhs.y * rhs.y, lhs.z * rhs.z, lhs.w * rhs.w); }

#include <map>
template <typename T>
inline T cclamp(const T& n, const T& lower, const T& upper) {
    return std::max(lower, std::min(n, upper));
}

inline float clerp(float a, float b, float f) {
    return cclamp<float>(a + f * (b - a), a > b ? b : a, a > b ? a : b);
}

inline ImColor ccollerp(ImColor a, ImColor b, float f) {
    return { a.Value.x + f * (b.Value.x - a.Value.x), a.Value.y + f * (b.Value.y - a.Value.y), a.Value.z + f * (b.Value.z - a.Value.z), a.Value.w + f * (b.Value.w - a.Value.w) };
}

struct tab_element {
    float element_opacity;
};

struct wdg_element {
    float selected_rect;
    ImVec4 checkmark;
};

void AddRadialGradient(ImDrawList* draw_list, const ImVec2& center, float radius, ImU32 col_in, ImU32 col_out)
{
    if (((col_in | col_out) & IM_COL32_A_MASK) == 0 || radius < 0.5f)
        return;

    // Use arc with automatic segment count
    draw_list->_PathArcToFastEx(center, radius, 0, IM_DRAWLIST_ARCFAST_SAMPLE_MAX, 0);
    const int count = draw_list->_Path.Size - 1;

    unsigned int vtx_base = draw_list->_VtxCurrentIdx;
    draw_list->PrimReserve(count * 3, count + 1);

    // Submit vertices
    const ImVec2 uv = draw_list->_Data->TexUvWhitePixel;
    draw_list->PrimWriteVtx(center, uv, col_in);
    for (int n = 0; n < count; n++)
        draw_list->PrimWriteVtx(draw_list->_Path[n], uv, col_out);

    // Submit a fan of triangles
    for (int n = 0; n < count; n++)
    {
        draw_list->PrimWriteIdx((ImDrawIdx)(vtx_base));
        draw_list->PrimWriteIdx((ImDrawIdx)(vtx_base + 1 + n));
        draw_list->PrimWriteIdx((ImDrawIdx)(vtx_base + 1 + ((n + 1) % count)));
    }
    draw_list->_Path.Size = 0;
}

float calc_item_width()
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    float w = window->Size.x - g.Style.WindowPadding.x * 2;
    if (w < 0.0f)
    {
        float region_max_x = GetContentRegionMaxAbs().x;
        w = ImMax(1.0f, region_max_x - window->DC.CursorPos.x + w);
    }
    w = IM_FLOOR(w);
    return w;
}


static const signed char    IM_S8_MIN = -128;
static const signed char    IM_S8_MAX = 127;
static const unsigned char  IM_U8_MIN = 0;
static const unsigned char  IM_U8_MAX = 0xFF;
static const signed short   IM_S16_MIN = -32768;
static const signed short   IM_S16_MAX = 32767;
static const unsigned short IM_U16_MIN = 0;
static const unsigned short IM_U16_MAX = 0xFFFF;
static const ImS32          IM_S32_MIN = INT_MIN;    // (-2147483647 - 1), (0x80000000);
static const ImS32          IM_S32_MAX = INT_MAX;    // (2147483647), (0x7FFFFFFF)
static const ImU32          IM_U32_MIN = 0;
static const ImU32          IM_U32_MAX = UINT_MAX;   // (0xFFFFFFFF)
#ifdef LLONG_MIN
static const ImS64          IM_S64_MIN = LLONG_MIN;  // (-9223372036854775807ll - 1ll);
static const ImS64          IM_S64_MAX = LLONG_MAX;  // (9223372036854775807ll);
#else
static const ImS64          IM_S64_MIN = -9223372036854775807LL - 1;
static const ImS64          IM_S64_MAX = 9223372036854775807LL;
#endif
static const ImU64          IM_U64_MIN = 0;
#ifdef ULLONG_MAX
static const ImU64          IM_U64_MAX = ULLONG_MAX; // (0xFFFFFFFFFFFFFFFFull);
#else
static const ImU64          IM_U64_MAX = (2ULL * 9223372036854775807LL + 1);
#endif

bool slider_behavior(const ImRect& bb, ImGuiID id, ImGuiDataType data_type, void* p_v, const void* p_min, const void* p_max, const char* format, ImGuiSliderFlags flags, ImRect* out_grab_bb, int* percent)
{
    // Read imgui.cpp "API BREAKING CHANGES" section for 1.78 if you hit this assert.
    IM_ASSERT((flags == 1 || (flags & ImGuiSliderFlags_InvalidMask_) == 0) && "Invalid ImGuiSliderFlags flag!  Has the 'float power' argument been mistakenly cast to flags? Call function with ImGuiSliderFlags_Logarithmic flags instead.");

    ImGuiContext& g = *GImGui;
    if ((g.LastItemData.InFlags & ImGuiItemFlags_ReadOnly) || (flags & ImGuiSliderFlags_ReadOnly))
        return false;

    switch (data_type)
    {
        case ImGuiDataType_S8:  { ImS32 v32 = (ImS32)*(ImS8*)p_v;  bool r = ImGui::SliderBehaviorT<ImS32, ImS32, float>(bb, id, ImGuiDataType_S32, &v32, *(const ImS8*)p_min,  *(const ImS8*)p_max,  format, flags, out_grab_bb, percent); if (r) *(ImS8*)p_v  = (ImS8)v32;  return r; }
        case ImGuiDataType_U8:  { ImU32 v32 = (ImU32)*(ImU8*)p_v;  bool r = ImGui::SliderBehaviorT<ImU32, ImS32, float>(bb, id, ImGuiDataType_U32, &v32, *(const ImU8*)p_min,  *(const ImU8*)p_max,  format, flags, out_grab_bb, percent); if (r) *(ImU8*)p_v  = (ImU8)v32;  return r; }
        case ImGuiDataType_S16: { ImS32 v32 = (ImS32)*(ImS16*)p_v; bool r = ImGui::SliderBehaviorT<ImS32, ImS32, float>(bb, id, ImGuiDataType_S32, &v32, *(const ImS16*)p_min, *(const ImS16*)p_max, format, flags, out_grab_bb, percent); if (r) *(ImS16*)p_v = (ImS16)v32; return r; }
        case ImGuiDataType_U16: { ImU32 v32 = (ImU32)*(ImU16*)p_v; bool r = ImGui::SliderBehaviorT<ImU32, ImS32, float>(bb, id, ImGuiDataType_U32, &v32, *(const ImU16*)p_min, *(const ImU16*)p_max, format, flags, out_grab_bb, percent); if (r) *(ImU16*)p_v = (ImU16)v32; return r; }
        case ImGuiDataType_S32:
            IM_ASSERT(*(const ImS32*)p_min >= IM_S32_MIN / 2 && *(const ImS32*)p_max <= IM_S32_MAX / 2);
            return ImGui::SliderBehaviorT<ImS32, ImS32, float >(bb, id, data_type, (ImS32*)p_v,  *(const ImS32*)p_min,  *(const ImS32*)p_max,  format, flags, out_grab_bb, percent);
        case ImGuiDataType_U32:
            IM_ASSERT(*(const ImU32*)p_max <= IM_U32_MAX / 2);
            return ImGui::SliderBehaviorT<ImU32, ImS32, float >(bb, id, data_type, (ImU32*)p_v,  *(const ImU32*)p_min,  *(const ImU32*)p_max,  format, flags, out_grab_bb, percent);
        case ImGuiDataType_S64:
            IM_ASSERT(*(const ImS64*)p_min >= IM_S64_MIN / 2 && *(const ImS64*)p_max <= IM_S64_MAX / 2);
            return ImGui::SliderBehaviorT<ImS64, ImS64, double>(bb, id, data_type, (ImS64*)p_v,  *(const ImS64*)p_min,  *(const ImS64*)p_max,  format, flags, out_grab_bb, percent);
        case ImGuiDataType_U64:
            IM_ASSERT(*(const ImU64*)p_max <= IM_U64_MAX / 2);
            return ImGui::SliderBehaviorT<ImU64, ImS64, double>(bb, id, data_type, (ImU64*)p_v,  *(const ImU64*)p_min,  *(const ImU64*)p_max,  format, flags, out_grab_bb, percent);
        case ImGuiDataType_Float:
            IM_ASSERT(*(const float*)p_min >= -FLT_MAX / 2.0f && *(const float*)p_max <= FLT_MAX / 2.0f);
            return ImGui::SliderBehaviorT<float, float, float >(bb, id, data_type, (float*)p_v,  *(const float*)p_min,  *(const float*)p_max,  format, flags, out_grab_bb, percent);
        case ImGuiDataType_Double:
            IM_ASSERT(*(const double*)p_min >= -DBL_MAX / 2.0f && *(const double*)p_max <= DBL_MAX / 2.0f);
            return ImGui::SliderBehaviorT<double, double, double>(bb, id, data_type, (double*)p_v, *(const double*)p_min, *(const double*)p_max, format, flags, out_grab_bb, percent);
        case ImGuiDataType_COUNT: break;
    }
    IM_ASSERT(0);
    return false;
}

void rendertextclipped_ex(ImColor color, ImDrawList* draw_list, const ImVec2& pos_min, const ImVec2& pos_max, const char* text, const char* text_display_end, const ImVec2* text_size_if_known, const ImVec2& align, const ImRect* clip_rect)
{
    // Perform CPU side clipping for single clipped element to avoid using scissor state
    ImVec2 pos = pos_min;
    const ImVec2 text_size = text_size_if_known ? *text_size_if_known : CalcTextSize(text, text_display_end, false, 0.0f);

    const ImVec2* clip_min = clip_rect ? &clip_rect->Min : &pos_min;
    const ImVec2* clip_max = clip_rect ? &clip_rect->Max : &pos_max;
    bool need_clipping = (pos.x + text_size.x >= clip_max->x) || (pos.y + text_size.y >= clip_max->y);
    if (clip_rect) // If we had no explicit clipping rectangle then pos==clip_min
        need_clipping |= (pos.x < clip_min->x) || (pos.y < clip_min->y);

    // Align whole block. We should defer that to the better rendering function when we'll have support for individual line alignment.
    if (align.x > 0.0f) pos.x = ImMax(pos.x, pos.x + (pos_max.x - pos.x - text_size.x) * align.x);
    if (align.y > 0.0f) pos.y = ImMax(pos.y, pos.y + (pos_max.y - pos.y - text_size.y) * align.y);

    // Render
    if (need_clipping)
    {
        ImVec4 fine_clip_rect(clip_min->x, clip_min->y, clip_max->x, clip_max->y);
        draw_list->AddText(NULL, 0.0f, pos, color, text, text_display_end, 0.0f, &fine_clip_rect);
    }
    else
    {
        draw_list->AddText(NULL, 0.0f, pos, color, text, text_display_end, 0.0f, NULL);
    }
}

void rendertextclipped(ImColor color, const ImVec2& pos_min, const ImVec2& pos_max, const char* text, const char* text_end, const ImVec2* text_size_if_known, const ImVec2& align, const ImRect* clip_rect)
{
    // Hide anything after a '##' string
    const char* text_display_end = FindRenderedTextEnd(text, text_end);
    const int text_len = (int)(text_display_end - text);
    if (text_len == 0)
        return;

    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    rendertextclipped_ex(color, window->DrawList, pos_min, pos_max, text, text_display_end, text_size_if_known, align, clip_rect);
    if (g.LogEnabled)
        LogRenderedText(&pos_min, text, text_display_end);
}

void rendertext(ImColor color, ImVec2 pos, const char* text, const char* text_end, bool hide_text_after_hash)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;

    // Hide anything after a '##' string
    const char* text_display_end;
    if (hide_text_after_hash)
    {
        text_display_end = FindRenderedTextEnd(text, text_end);
    }
    else
    {
        if (!text_end)
            text_end = text + strlen(text); // FIXME-OPT
        text_display_end = text_end;
    }

    if (text != text_display_end) window->DrawList->AddText(g.Font, g.FontSize, pos, color, text, text_display_end);
}

struct button_state
{
    ImVec4 text;
    ImVec4 bg;
    bool hovered, active = false;
};

bool button_ex(const char* label, const ImVec2& size_arg, bool makeup, ImGuiButtonFlags flags)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);
    const ImVec2 label_size = ImGui::CalcTextSize(label, NULL, true);

    ImVec2 pos = window->DC.CursorPos;
    if ((flags & ImGuiButtonFlags_AlignTextBaseLine) && style.FramePadding.y < window->DC.CurrLineTextBaseOffset) // Try to vertically align buttons that are smaller/have no padding so that text baseline matches (bit hacky, since it shouldn't be a flag)
        pos.y += window->DC.CurrLineTextBaseOffset - style.FramePadding.y;
    ImVec2 size = ImGui::CalcItemSize(size_arg, ImGui::GetWindowSize().x - style.WindowPadding.x * 2, label_size.y + 30 + style.FramePadding.y);

    const ImRect bb(pos, pos + size);
    ImGui::ItemSize(size, style.FramePadding.y);
    if (!ImGui::ItemAdd(bb, id))
        return false;

    if (g.LastItemData.InFlags & ImGuiItemFlags_ButtonRepeat)
        flags |= ImGuiButtonFlags_Repeat;

    bool hovered, held;
    bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held, flags);

    // Render
    const ImU32 col = ImGui::GetColorU32((held && hovered) ? ImGuiCol_ButtonActive : hovered ? ImGuiCol_ButtonHovered : ImGuiCol_Button);
    ImGui::RenderNavHighlight(bb, id);

    static std::map<ImGuiID, button_state> anim223;
    auto it_anim2 = anim223.find(id);
    if (it_anim2 == anim223.end())
    {
        anim223.insert({ id, button_state() });
        it_anim2 = anim223.find(id);
    }

    bool hav = hovered || pressed;

    it_anim2->second.text = ImLerp(it_anim2->second.text, hav  ? ImColor(0, 0, 0, (int)(style.Alpha * 255)) : ImColor(0, 0, 0, (int)(style.Alpha * 160)), g.IO.DeltaTime * 6.f);
    it_anim2->second.bg = ImLerp(it_anim2->second.bg, hovered ? ImColor(GetStyleColorVec4(ImGuiCol_Accent).x, GetStyleColorVec4(ImGuiCol_Accent).y, GetStyleColorVec4(ImGuiCol_Accent).z, style.Alpha) : ImColor(GetStyleColorVec4(ImGuiCol_Accent).x, GetStyleColorVec4(ImGuiCol_Accent).y, GetStyleColorVec4(ImGuiCol_Accent).z, style.Alpha/2), g.IO.DeltaTime * 6.f);

    if (pressed)
        it_anim2->second.bg = ImColor(0, 0, 0, (int)(style.Alpha * 120));

    if (!makeup) ImGui::RenderFrame(bb.Min, bb.Max, col, true, style.FrameRounding);
    else {
        window->DrawList->AddRectFilled(bb.Min, bb.Max, ImColor(it_anim2->second.bg), style.FrameRounding);
    }

    if (g.LogEnabled)
        ImGui::LogSetNextTextDecoration("[", "]");
    rendertextclipped(it_anim2->second.text, bb.Min + style.FramePadding, bb.Max - style.FramePadding, label, NULL, &label_size, style.ButtonTextAlign, &bb);

    // Automatically close popups
    //if (pressed && !(flags & ImGuiButtonFlags_DontClosePopups) && (window->Flags & ImGuiWindowFlags_Popup))
    //    CloseCurrentPopup();

    IMGUI_TEST_ENGINE_ITEM_INFO(id, label, g.LastItemData.StatusFlags);
    return pressed;
}

bool button_wex(const char* label, const ImVec2& size_arg, bool makeup, ImGuiButtonFlags flags)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);
    const ImVec2 label_size = ImGui::CalcTextSize(label, NULL, true);

    ImVec2 pos = window->DC.CursorPos;
    if ((flags & ImGuiButtonFlags_AlignTextBaseLine) && style.FramePadding.y < window->DC.CurrLineTextBaseOffset) // Try to vertically align buttons that are smaller/have no padding so that text baseline matches (bit hacky, since it shouldn't be a flag)
        pos.y += window->DC.CurrLineTextBaseOffset - style.FramePadding.y;
    ImVec2 size = CalcItemSize(size_arg, label_size.x + style.FramePadding.x * 2.0f, label_size.y + style.FramePadding.y * 2.0f);

    const ImRect bb(pos, pos + size);
    ImGui::ItemSize(size, style.FramePadding.y);
    if (!ImGui::ItemAdd(bb, id))
        return false;

    if (g.LastItemData.InFlags & ImGuiItemFlags_ButtonRepeat)
        flags |= ImGuiButtonFlags_Repeat;

    bool hovered, held;
    bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held, flags);

    // Render
    const ImU32 col = ImGui::GetColorU32((held && hovered) ? ImGuiCol_ButtonActive : hovered ? ImGuiCol_ButtonHovered : ImGuiCol_Button);
    ImGui::RenderNavHighlight(bb, id);

    static std::map<ImGuiID, button_state> anim223;
    auto it_anim2 = anim223.find(id);
    if (it_anim2 == anim223.end())
    {
        anim223.insert({ id, button_state() });
        it_anim2 = anim223.find(id);
    }

    bool hav = hovered || pressed;

    it_anim2->second.text = ImLerp(it_anim2->second.text, hav  ? ImColor(255, 255, 255, (int)(style.Alpha * 255)) : ImColor(200, 200, 200, (int)(style.Alpha * 255)), g.IO.DeltaTime * 6.f);
    it_anim2->second.bg = ImLerp(it_anim2->second.bg, hovered ? ImColor(GetStyleColorVec4(ImGuiCol_Accent).x, GetStyleColorVec4(ImGuiCol_Accent).y, GetStyleColorVec4(ImGuiCol_Accent).z, style.Alpha) : ImColor(GetStyleColorVec4(ImGuiCol_Accent).x, GetStyleColorVec4(ImGuiCol_Accent).y, GetStyleColorVec4(ImGuiCol_Accent).z, style.Alpha/2), g.IO.DeltaTime * 6.f);

    if (pressed)
        it_anim2->second.bg = ImColor(0, 0, 0, (int)(style.Alpha * 120));

    if (!makeup) ImGui::RenderFrame(bb.Min, bb.Max, col, true, style.FrameRounding);
    else {
        window->DrawList->AddRectFilled(bb.Min, bb.Max, ImColor(it_anim2->second.bg), style.FrameRounding);
    }

    if (g.LogEnabled)
        ImGui::LogSetNextTextDecoration("[", "]");
    rendertextclipped(it_anim2->second.text, bb.Min + style.FramePadding, bb.Max - style.FramePadding, label, NULL, &label_size, style.ButtonTextAlign, &bb);

    // Automatically close popups
    //if (pressed && !(flags & ImGuiButtonFlags_DontClosePopups) && (window->Flags & ImGuiWindowFlags_Popup))
    //    CloseCurrentPopup();

    IMGUI_TEST_ENGINE_ITEM_INFO(id, label, g.LastItemData.StatusFlags);
    return pressed;
}

struct slider_state
{
    ImVec4 text;
    ImVec4 bgcolor;
    bool hovered = false;
};

#include <unordered_map>

bool slider_scalar(const char* label, ImGuiDataType data_type, void* p_data, const void* p_min, const void* p_max, const char* format, ImGuiSliderFlags flags)
{
    static std::map<void*, float> anim1;

    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);
    const float w = calc_item_width();

    const ImVec2 label_size = CalcTextSize(label, NULL, true);

    const ImRect slider_bb(window->DC.CursorPos + ImVec2(0, label_size.y + style.ItemInnerSpacing.y), window->DC.CursorPos + ImVec2(w, label_size.y + g.FontSize));
    const ImRect total_bb(window->DC.CursorPos, slider_bb.Max);

    const bool temp_input_allowed = (flags & ImGuiSliderFlags_NoInput) == 0;
    ItemSize(total_bb, style.FramePadding.y);
    if (!ItemAdd(total_bb, id, &slider_bb, temp_input_allowed ? ImGuiItemFlags_Inputable : 0))
        return false;

    // Default format string when passing NULL
    if (format == NULL)
        format = DataTypeGetInfo(data_type)->PrintFmt;

    const bool hovered = ItemHoverable(total_bb, id);
    // Tabbing or CTRL-clicking on Slider turns it into an input box
    const bool clicked = hovered && IsMouseClicked(0, id);
    const bool make_active = (clicked || g.NavActivateId == id);
    if (make_active && clicked)
        SetKeyOwner(ImGuiKey_MouseLeft, id);

    if (make_active)
    {
        SetActiveID(id, window);
        SetFocusID(id, window);
        FocusWindow(window);
        g.ActiveIdUsingNavDirMask |= (1 << ImGuiDir_Left) | (1 << ImGuiDir_Right);
    }

    int percent = 0;

    // Draw frame
    const ImU32 frame_col = GetColorU32(g.ActiveId == id ? ImGuiCol_FrameBgActive : hovered ? ImGuiCol_FrameBgHovered : ImGuiCol_FrameBg);
    RenderNavHighlight(slider_bb, id);
    //RenderFrame(slider_bb.Min, slider_bb.Max, frame_col, true, g.Style.FrameRounding);

    // Slider behavior
    ImRect grab_bb;
    const bool value_changed = slider_behavior(slider_bb, id, data_type, p_data, p_min, p_max, format, flags, &grab_bb, &percent);
    if (value_changed)
        MarkItemEdited(id);

    if (value_changed)
        anim1[p_data] = 1;
    else
        anim1[p_data] = clerp(anim1[p_data], 0, GImGui->IO.DeltaTime * 10);

    static std::map<ImGuiID, slider_state> anim;
    auto it_anim = anim.find(id);

    if (it_anim == anim.end())
    {
        anim.insert({ id, slider_state() });
        it_anim = anim.find(id);
    }

    static std::map <ImGuiID, wdg_element> anim23;
    auto it_anim23 = anim23.find(id);
    if (it_anim23 == anim23.end())
    {
        anim23.insert({ id, { 0.0f } });
        it_anim23 = anim23.find(id);
    }

    bool hoveredAndChanged = hovered || value_changed || IsItemActive();

    it_anim23->second.selected_rect = ImLerp(it_anim23->second.selected_rect, hoveredAndChanged ? (g.Style.Alpha / 5) : 0.0f, 0.08f * (1.0f - ImGui::GetIO().DeltaTime));

    it_anim->second.text = ImLerp(it_anim->second.text, hoveredAndChanged ? ImColor(255, 255, 255, (int)(style.Alpha * 255)) : ImColor(160, 160, 160, (int)(style.Alpha * 255)), g.IO.DeltaTime * 6.f);

    ImVec2 linestart = ImVec2(slider_bb.Min.x, clerp(slider_bb.Min.y, slider_bb.Max.y, 0.5f));
    ImVec2 lineend = ImVec2(clerp(grab_bb.Min.x, grab_bb.Max.x, 0.5f), clerp(grab_bb.Min.y, grab_bb.Max.y, 0.5f));
    ImVec2 backgroundend = ImVec2(slider_bb.Max.x, clerp(slider_bb.Min.y, slider_bb.Max.y, 0.5f));
    ImVec2 linesize = ImVec2(0, 6 *1.5* ImGui::GetIO().FontGlobalScale);

    ImColor fillcolor = ImColor(GetStyleColorVec4(ImGuiCol_Accent).x, GetStyleColorVec4(ImGuiCol_Accent).y, GetStyleColorVec4(ImGuiCol_Accent).z);

    static std::unordered_map< ImGuiID, float > values;
    auto value = values.find( id );

    if ( value == values.end( ) ) {
        values.insert( { id, 0.f } );
        value = values.find( id );
    }

    value->second = ImLerp( value->second, ( float )percent / 100.f * slider_bb.GetWidth( ), 0.1f );

    window->DrawList->AddRectFilled(linestart - 2*1.5 + ImVec2(2*1.5, 0), backgroundend + 2*1.5 - ImVec2(2*1.5, 0), ImColor(GetStyleColorVec4(ImGuiCol_WindowBg).x, GetStyleColorVec4(ImGuiCol_WindowBg).y, GetStyleColorVec4(ImGuiCol_WindowBg).z, style.Alpha), 2);
    window->DrawList->AddRectFilled(linestart - 2*1.5 + ImVec2(2*1.5, 0), backgroundend + 2*1.5 - ImVec2(2*1.5, 0), ImColor(GetStyleColorVec4(ImGuiCol_Accent).x, GetStyleColorVec4(ImGuiCol_Accent).y, GetStyleColorVec4(ImGuiCol_Accent).z, it_anim23->second.selected_rect), 2);
    window->DrawList->AddRectFilled(linestart - 2*1.5 + ImVec2(2*1.5, 0), backgroundend + 2*1.5 - ImVec2(2*1.5, 0), ImColor(it_anim->second.bgcolor), 2);
    //window->DrawList->AddRectFilledMultiColor(linestart - linesize, lineend + linesize, ImColor(fillcolor.Value.x, fillcolor.Value.y, fillcolor.Value.z, 0.f), ImColor(fillcolor.Value.x, fillcolor.Value.y, fillcolor.Value.z, 1.f), ImColor(fillcolor.Value.x, fillcolor.Value.y, fillcolor.Value.z, 1.f), ImColor(fillcolor.Value.x, fillcolor.Value.y, fillcolor.Value.z, 0.f));
    window->DrawList->AddRectFilled(linestart - 2*1.5 + ImVec2(2*1.5, 0), ImVec2(slider_bb.Min.x + value->second, lineend.y) + 2*1.5 - ImVec2(2*1.5, 0), ImColor(GetStyleColorVec4(ImGuiCol_Accent).x, GetStyleColorVec4(ImGuiCol_Accent).y, GetStyleColorVec4(ImGuiCol_Accent).z, style.Alpha), 2);
    //window->DrawList->AddRect(linestart - linesize, ImVec2(slider_bb.Min.x + value->second, lineend.y) + linesize, ImColor(GetStyleColorVec4(ImGuiCol_Accent).x, GetStyleColorVec4(ImGuiCol_Accent).y, GetStyleColorVec4(ImGuiCol_Accent).z, style.Alpha), style.GrabRounding);
    window->DrawList->AddCircleFilled(ImVec2(slider_bb.Min.x + value->second, lineend.y), 1.5*(7 * (anim1[p_data] / 2.0f + 1.0f)), ImColor(GetStyleColorVec4(ImGuiCol_Accent).x, GetStyleColorVec4(ImGuiCol_Accent).y, GetStyleColorVec4(ImGuiCol_Accent).z, style.Alpha));

    char value_buf[64];
    const char* value_buf_end = value_buf + DataTypeFormatString(value_buf, IM_ARRAYSIZE(value_buf), data_type, p_data, format);

    const ImVec2 value_size = CalcTextSize(value_buf_end);
    rendertextclipped(it_anim->second.text, total_bb.Min, ImVec2(total_bb.Max.x, total_bb.Max.y - g.FontSize), value_buf, value_buf_end, NULL, ImVec2(1.f, 1.f), NULL);

    if (label_size.x > 0.0f)
        rendertext(it_anim->second.text, total_bb.Min, label, NULL, false);

    IMGUI_TEST_ENGINE_ITEM_INFO(id, label, g.LastItemData.StatusFlags | (temp_input_allowed ? ImGuiItemStatusFlags_Inputable : 0));
    return value_changed;
}

static float CalcMaxPopupHeightFromItemCount(int items_count)
{
    ImGuiContext& g = *GImGui;
    if (items_count <= 0)
        return FLT_MAX;
    return (g.FontSize + g.Style.ItemSpacing.y) * items_count - g.Style.ItemSpacing.y + (g.Style.WindowPadding.y * 2);
}

// Getter for the old Combo() API: const char*[]
static bool Items_ArrayGetter(void* data, int idx, const char** out_text)
{
    const char* const* items = (const char* const*)data;
    if (out_text)
        *out_text = items[idx];
    return true;
}

// Getter for the old Combo() API: "item1\0item2\0item3\0"
static bool Items_SingleStringGetter(void* data, int idx, const char** out_text)
{
    // FIXME-OPT: we could pre-compute the indices to fasten this. But only 1 active combo means the waste is limited.
    const char* items_separated_by_zeros = (const char*)data;
    int items_count = 0;
    const char* p = items_separated_by_zeros;
    while (*p)
    {
        if (idx == items_count)
            break;
        p += strlen(p) + 1;
        items_count++;
    }
    if (!*p)
        return false;
    if (out_text)
        *out_text = p;
    return true;
}

struct selectable_element {
    float opacity, checkmark_anim;
};

bool selectable(const char* label, bool selected, ImGuiSelectableFlags flags, const ImVec2& size_arg)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;

    // Submit label or explicit size to ItemSize(), whereas ItemAdd() will submit a larger/spanning rectangle.
    ImGuiID id = window->GetID(label);
    ImVec2 label_size = CalcTextSize(label, NULL, true);
    ImVec2 size(size_arg.x != 0.0f ? size_arg.x : label_size.x, size_arg.y != 0.0f ? size_arg.y : label_size.y + 3);
    ImVec2 pos = window->DC.CursorPos;
    pos.y += window->DC.CurrLineTextBaseOffset;
    ItemSize(size, 0.0f);

    // Fill horizontal space
    // We don't support (size < 0.0f) in Selectable() because the ItemSpacing extension would make explicitly right-aligned sizes not visibly match other widgets.
    const bool span_all_columns = (flags & ImGuiSelectableFlags_SpanAllColumns) != 0;
    const float min_x = span_all_columns ? window->ParentWorkRect.Min.x : pos.x;
    const float max_x = span_all_columns ? window->ParentWorkRect.Max.x : window->WorkRect.Max.x;
    if (size_arg.x == 0.0f || (flags & ImGuiSelectableFlags_SpanAvailWidth))
        size.x = ImMax(label_size.x, max_x - min_x);

    // Text stays at the submission position, but bounding box may be extended on both sides
    const ImVec2 text_min = pos;
    const ImVec2 text_max(min_x + size.x, pos.y + size.y);

    // Selectables are meant to be tightly packed together with no click-gap, so we extend their box to cover spacing between selectable.
    ImRect bb(min_x, pos.y, text_max.x, text_max.y);
    if ((flags & ImGuiSelectableFlags_NoPadWithHalfSpacing) == 0)
    {
        const float spacing_x = span_all_columns ? 0.0f : style.ItemSpacing.x;
        const float spacing_y = style.ItemSpacing.y;
        const float spacing_L = IM_FLOOR(spacing_x * 0.50f);
        const float spacing_U = IM_FLOOR(spacing_y * 0.50f);
        bb.Min.x -= spacing_L;
        bb.Min.y -= spacing_U;
        bb.Max.x += (spacing_x - spacing_L);
        bb.Max.y += (spacing_y - spacing_U);
    }
    //if (g.IO.KeyCtrl) { GetForegroundDrawList()->AddRect(bb.Min, bb.Max, IM_COL32(0, 255, 0, 255)); }

    // Modify ClipRect for the ItemAdd(), faster than doing a PushColumnsBackground/PushTableBackground for every Selectable..
    const float backup_clip_rect_min_x = window->ClipRect.Min.x;
    const float backup_clip_rect_max_x = window->ClipRect.Max.x;
    if (span_all_columns)
    {
        window->ClipRect.Min.x = window->ParentWorkRect.Min.x;
        window->ClipRect.Max.x = window->ParentWorkRect.Max.x;
    }

    const bool disabled_item = (flags & ImGuiSelectableFlags_Disabled) != 0;
    const bool item_add = ItemAdd(bb, id, NULL, disabled_item ? ImGuiItemFlags_Disabled : ImGuiItemFlags_None);
    if (span_all_columns)
    {
        window->ClipRect.Min.x = backup_clip_rect_min_x;
        window->ClipRect.Max.x = backup_clip_rect_max_x;
    }

    if (!item_add)
        return false;

    const bool disabled_global = (g.CurrentItemFlags & ImGuiItemFlags_Disabled) != 0;
    if (disabled_item && !disabled_global) // Only testing this as an optimization
        BeginDisabled();

    // FIXME: We can standardize the behavior of those two, we could also keep the fast path of override ClipRect + full push on render only,
    // which would be advantageous since most selectable are not selected.
    if (span_all_columns && window->DC.CurrentColumns)
        PushColumnsBackground();
    else if (span_all_columns && g.CurrentTable)
        TablePushBackgroundChannel();

    // We use NoHoldingActiveID on menus so user can click and _hold_ on a menu then drag to browse child entries
    ImGuiButtonFlags button_flags = 0;
    if (flags & ImGuiSelectableFlags_NoHoldingActiveID) { button_flags |= ImGuiButtonFlags_NoHoldingActiveId; }
    if (flags & ImGuiSelectableFlags_SelectOnClick) { button_flags |= ImGuiButtonFlags_PressedOnClick; }
    if (flags & ImGuiSelectableFlags_SelectOnRelease) { button_flags |= ImGuiButtonFlags_PressedOnRelease; }
    if (flags & ImGuiSelectableFlags_AllowDoubleClick) { button_flags |= ImGuiButtonFlags_PressedOnClickRelease | ImGuiButtonFlags_PressedOnDoubleClick; }
    if (flags & ImGuiSelectableFlags_AllowItemOverlap) { button_flags |= ImGuiButtonFlags_AllowItemOverlap; }

    const bool was_selected = selected;
    bool hovered, held;
    bool pressed = ButtonBehavior(bb, id, &hovered, &held, button_flags);

    // Auto-select when moved into
    // - This will be more fully fleshed in the range-select branch
    // - This is not exposed as it won't nicely work with some user side handling of shift/control
    // - We cannot do 'if (g.NavJustMovedToId != id) { selected = false; pressed = was_selected; }' for two reasons
    //   - (1) it would require focus scope to be set, need exposing PushFocusScope() or equivalent (e.g. BeginSelection() calling PushFocusScope())
    //   - (2) usage will fail with clipped items
    //   The multi-select API aim to fix those issues, e.g. may be replaced with a BeginSelection() API.
    if ((flags & ImGuiSelectableFlags_SelectOnNav) && g.NavJustMovedToId != 0 && g.NavJustMovedToFocusScopeId == g.CurrentFocusScopeId)
        if (g.NavJustMovedToId == id)
            selected = pressed = true;

    // Update NavId when clicking or when Hovering (this doesn't happen on most widgets), so navigation can be resumed with gamepad/keyboard
    if (pressed || (hovered && (flags & ImGuiSelectableFlags_SetNavIdOnHover)))
    {
        if (!g.NavDisableMouseHover && g.NavWindow == window && g.NavLayer == window->DC.NavLayerCurrent)
        {
            SetNavID(id, window->DC.NavLayerCurrent, g.CurrentFocusScopeId, WindowRectAbsToRel(window, bb)); // (bb == NavRect)
            g.NavDisableHighlight = true;
        }
    }
    if (pressed)
        MarkItemEdited(id);

    if (flags & ImGuiSelectableFlags_AllowItemOverlap)
        SetItemAllowOverlap();

    // In this branch, Selectable() cannot toggle the selection so this will never trigger.
    if (selected != was_selected) //-V547
        g.LastItemData.StatusFlags |= ImGuiItemStatusFlags_ToggledSelection;

    // Render
    if (hovered || selected || held)
        hovered = true;

    if (span_all_columns && window->DC.CurrentColumns)
        PopColumnsBackground();
    else if (span_all_columns && g.CurrentTable)
        TablePopBackgroundChannel();

    static std::map <ImGuiID, selectable_element> anim;
    auto it_anim = anim.find(id);
    if (it_anim == anim.end())
    {
        anim.insert({ id, { 0.0f, 0.0f } });
        it_anim = anim.find(id);
    }

    it_anim->second.opacity = ImLerp(it_anim->second.opacity, hovered ? g.Style.Alpha : 0.0f, 0.10f * (1.0f - ImGui::GetIO().DeltaTime));
    it_anim->second.checkmark_anim = ImLerp(it_anim->second.checkmark_anim, selected ? g.Style.Alpha : 0.0f, 0.10f * (1.0f - ImGui::GetIO().DeltaTime));

    window->DrawList->AddRectFilled(bb.Min, bb.Max, ImColor(1.0f, 1.0f, 1.0f, it_anim->second.opacity * 0.1f), 3.0f);
    RenderCheckMark(window->DrawList, ImVec2(bb.Min.x + 8, bb.Min.y + 14), ImColor(GetStyleColorVec4(ImGuiCol_Accent).x, GetStyleColorVec4(ImGuiCol_Accent).y, GetStyleColorVec4(ImGuiCol_Accent).z, it_anim->second.checkmark_anim), 9.0f);

    window->DrawList->AddText(text_min + ImVec2(18, 1), GetColorU32(ImGuiCol_Text), label);

    // Automatically close popups
    if (pressed && (window->Flags & ImGuiWindowFlags_Popup) && !(flags & ImGuiSelectableFlags_DontClosePopups) && !(g.LastItemData.InFlags & ImGuiItemFlags_SelectableDontClosePopup))
        CloseCurrentPopup();

    if (disabled_item && !disabled_global)
        EndDisabled();

    IMGUI_TEST_ENGINE_ITEM_INFO(id, label, g.LastItemData.StatusFlags);
    return pressed; //-V1020
}

bool selectable(const char* label, bool* p_selected, ImGuiSelectableFlags flags, const ImVec2& size_arg)
{
    if (selectable(label, *p_selected, flags, size_arg))
    {
        *p_selected = !*p_selected;
        return true;
    }
    return false;
}

struct combo_state
{
    ImVec4 text;
    bool hovered = false;
    bool opened_combo = false;
    float open_anim;
};

struct combo_element {
    float open_anim, arrow_anim;
};

bool begin_combo(const char* label, const char* preview_value, ImGuiComboFlags flags)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = GetCurrentWindow();

    ImGuiNextWindowDataFlags backup_next_window_data_flags = g.NextWindowData.Flags;
    g.NextWindowData.ClearFlags(); // We behave like Begin() and need to consume those values
    if (window->SkipItems)
        return false;

    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);
    IM_ASSERT((flags & (ImGuiComboFlags_NoArrowButton | ImGuiComboFlags_NoPreview)) != (ImGuiComboFlags_NoArrowButton | ImGuiComboFlags_NoPreview)); // Can't use both flags together

    static std::map<ImGuiID, combo_state> anim;
    auto it_anim = anim.find(id);

    if (it_anim == anim.end())
    {
        anim.insert({ id, combo_state() });
        it_anim = anim.find(id);
    }

    static std::map <ImGuiID, combo_element> anim2;
    auto it_anim2 = anim2.find(id);
    if (it_anim2 == anim2.end())
    {
        anim2.insert({ id, {0.0f, 0.0f} });
        it_anim2 = anim2.find(id);
    }

    const float arrow_size = (flags & ImGuiComboFlags_NoArrowButton) ? 0.0f : GetFrameHeight();
    const ImVec2 label_size = CalcTextSize(label, NULL, true);
    const float w = (flags & ImGuiComboFlags_NoPreview) ? arrow_size : calc_item_width();

    const ImRect label_bb(window->DC.CursorPos, window->DC.CursorPos + label_size.y);
    const ImRect bb(ImVec2(window->DC.CursorPos.x, label_bb.Max.y + style.ItemInnerSpacing.y - 10), ImVec2(window->DC.CursorPos.x, label_bb.Max.y + style.ItemInnerSpacing.y + 10) + ImVec2(w, label_size.y + style.FramePadding.y * 2.0f));
    const ImRect total_bb(bb.Min, bb.Max + ImVec2(0.0f, label_size.y > 0.0f ? style.ItemInnerSpacing.y + label_size.y : 0.0f));
    ItemSize(total_bb, style.FramePadding.y);
    if (!ItemAdd(total_bb, id, &bb))
        return false;

    // Open on click
    bool hovered, held;
    bool pressed = ButtonBehavior(bb, id, &hovered, &held);
    const ImGuiID popup_id = ImHashStr("##ComboPopup", 0, id);
    bool popup_open = IsPopupOpen(popup_id, ImGuiPopupFlags_None);
    if (pressed && !popup_open)
    {
        OpenPopupEx(popup_id, ImGuiPopupFlags_None);
        popup_open = true;
    }

    if (!popup_open) it_anim->second.open_anim = 0.0f;
    if (!popup_open) it_anim2->second.open_anim = 0.0f;

    if (hovered && g.IO.MouseClicked[0] || it_anim->second.opened_combo && g.IO.MouseClicked[0] && !it_anim->second.hovered) it_anim->second.opened_combo = !it_anim->second.opened_combo;

    //it_anim->second.text = ImLerp(it_anim->second.text, it_anim->second.opened_combo ? ImColor(255, 255, 255, (int)(style.Alpha * 255)) : hovered ? ImColor(255, 255, 255, (int)(style.Alpha * 255)) : ImColor(160, 160, 160, (int)(style.Alpha * 255)), g.IO.DeltaTime * 6.f);
    bool pmtbool = hovered || it_anim->second.opened_combo;
    it_anim->second.text = ImLerp(it_anim->second.text, pmtbool ? ImColor(255, 255, 255, (int)(style.Alpha * 255)) : ImColor(160, 160, 160, (int)(style.Alpha * 255)), g.IO.DeltaTime * 6.f);

    // Render shape
    static std::map <ImGuiID, wdg_element> anim22;
    auto it_anim22 = anim22.find(id);
    if (it_anim22 == anim22.end())
    {
        anim22.insert({ id, { 0.0f } });
        it_anim22 = anim22.find(id);
    }

    static std::map <ImGuiID, wdg_element> anim3;
    auto it_anim3 = anim3.find(id);
    if (it_anim3 == anim3.end())
    {
        anim3.insert({ id, { 0.0f } });
        it_anim3 = anim3.find(id);
    }

    auto clickable = bb;

    it_anim2->second.open_anim = ImLerp(it_anim2->second.open_anim, popup_open ? g.Style.Alpha : 0.0f, 0.04f * (1.0f - ImGui::GetIO().DeltaTime));
    it_anim2->second.arrow_anim = ImLerp(it_anim2->second.arrow_anim, popup_open ? g.Style.Alpha / 3 : 0.0f, 0.05f * (1.0f - ImGui::GetIO().DeltaTime));

    const float value_x2 = ImMax(bb.Min.x, bb.Max.x - arrow_size);

    it_anim3->second.selected_rect = ImLerp(it_anim3->second.selected_rect, pmtbool ? (g.Style.Alpha / 5) : 0.0f, 0.08f * (1.0f - ImGui::GetIO().DeltaTime));
    it_anim22->second.selected_rect = ImLerp(it_anim22->second.selected_rect, it_anim->second.opened_combo ? g.Style.Alpha : (hovered ? (g.Style.Alpha / 5) : 0.0f), 0.08f * (1.0f - ImGui::GetIO().DeltaTime));

    //const ImU32 frame_col = GetColorU32(hovered ? ImGuiCol_FrameBgHovered : ImGuiCol_FrameBg);

    RenderNavHighlight(bb, id);
    if (!(flags & ImGuiComboFlags_NoPreview)) {
        window->DrawList->AddRectFilled(bb.Min, ImVec2(value_x2 + arrow_size, bb.Max.y), ImColor(GetStyleColorVec4(ImGuiCol_WindowBg).x, GetStyleColorVec4(ImGuiCol_WindowBg).y, GetStyleColorVec4(ImGuiCol_WindowBg).z, g.Style.Alpha), style.FrameRounding, ImDrawFlags_RoundCornersAll);
        window->DrawList->AddRectFilled(bb.Min, ImVec2(value_x2 + arrow_size, bb.Max.y), ImColor(GetStyleColorVec4(ImGuiCol_Accent).x, GetStyleColorVec4(ImGuiCol_Accent).y, GetStyleColorVec4(ImGuiCol_Accent).z, it_anim3->second.selected_rect), style.FrameRounding, ImDrawFlags_RoundCornersAll);

    }
    if (!(flags & ImGuiComboFlags_NoArrowButton))
    {
        ImU32 text_col = GetColorU32(ImGuiCol_Text);
        /*if (value_x2 + arrow_size - style.FramePadding.x <= bb.Max.x) {
            window->DrawList->AddLine(ImVec2(value_x2 + 5, clickable.Min.y + 12), ImVec2(value_x2 + 8, clickable.Min.y + 16), ImColor(1.0f, 1.0f, 1.0f, 0.6f + it_anim2->second.arrow_anim));
            window->DrawList->AddLine(ImVec2(value_x2 + 8, clickable.Min.y + 16), ImVec2(value_x2 + 12, clickable.Min.y + 11), ImColor(1.0f, 1.0f, 1.0f, 0.6f + it_anim2->second.arrow_anim));

            window->DrawList->AddLine(ImVec2(value_x2 + 4, clickable.Min.y + 12), ImVec2(value_x2 + 8, clickable.Min.y + 17), ImColor(1.0f, 1.0f, 1.0f, 0.6f + it_anim2->second.arrow_anim));
            window->DrawList->AddLine(ImVec2(value_x2 + 8, clickable.Min.y + 17), ImVec2(value_x2 + 13, clickable.Min.y + 11), ImColor(1.0f, 1.0f, 1.0f, 0.6f + it_anim2->second.arrow_anim));
        }*/
        //later
        RenderArrow(window->DrawList, ImVec2(value_x2 + style.FramePadding.y - 10, bb.Min.y + 9 + style.FramePadding.y), ImColor(it_anim->second.text), ImGuiDir_Down, 1.0f);
    }
    RenderFrameBorder(bb.Min, bb.Max, style.FrameRounding);

    // Custom preview
    if (flags & ImGuiComboFlags_CustomPreview)
    {
        g.ComboPreviewData.PreviewRect = ImRect(bb.Min.x, bb.Min.y, value_x2, bb.Max.y);
        IM_ASSERT(preview_value == NULL || preview_value[0] == 0);
        preview_value = NULL;
    }

    // Render preview and label
    if (preview_value != NULL && !(flags & ImGuiComboFlags_NoPreview))
    {
        if (g.LogEnabled)
            LogSetNextTextDecoration("{", "}");
        rendertextclipped(it_anim->second.text, bb.Min + style.FramePadding + ImVec2(10, 9), ImVec2(value_x2, bb.Max.y), preview_value, NULL, NULL, { 0,0 }, NULL);
    }
    if (label_size.x > 0)
        rendertext(it_anim->second.text, label_bb.Min, label, NULL, true);

    if (!popup_open)
        return false;

    it_anim->second.hovered = IsWindowHovered();
    if (it_anim->second.hovered && g.IO.MouseClicked[0]) it_anim->second.opened_combo = false;

    g.NextWindowData.Flags = backup_next_window_data_flags;

    if (!IsPopupOpen(popup_id, ImGuiPopupFlags_None))
    {
        g.NextWindowData.ClearFlags();
        return false;
    }

    it_anim->second.open_anim = ImLerp(it_anim->second.open_anim, popup_open ? 1.0f : 0.0f, 0.04f * (ImGui::GetIO().DeltaTime * 150));

    // Set popup size
    float w2 = bb.GetWidth();
    if (g.NextWindowData.Flags & ImGuiNextWindowDataFlags_HasSizeConstraint)
    {
        g.NextWindowData.SizeConstraintRect.Min.x = ImMax(g.NextWindowData.SizeConstraintRect.Min.x, w2);
    }
    else
    {
        if ((flags & ImGuiComboFlags_HeightMask_) == 0)
            flags |= ImGuiComboFlags_HeightRegular;
        IM_ASSERT(ImIsPowerOfTwo(flags & ImGuiComboFlags_HeightMask_)); // Only one
        int popup_max_height_in_items = -1;
        if (flags & ImGuiComboFlags_HeightRegular)     popup_max_height_in_items = 8;
        else if (flags & ImGuiComboFlags_HeightSmall)  popup_max_height_in_items = 4;
        else if (flags & ImGuiComboFlags_HeightLarge)  popup_max_height_in_items = 20;
        ImVec2 constraint_min(0.0f, 0.0f), constraint_max(FLT_MAX, FLT_MAX);
        if ((g.NextWindowData.Flags & ImGuiNextWindowDataFlags_HasSize) == 0 || g.NextWindowData.SizeVal.x <= 0.0f) // Don't apply constraints if user specified a size
            constraint_min.x = w2;
        if ((g.NextWindowData.Flags & ImGuiNextWindowDataFlags_HasSize) == 0 || g.NextWindowData.SizeVal.y <= 0.0f)
            constraint_max.y = CalcMaxPopupHeightFromItemCount(popup_max_height_in_items);
        SetNextWindowSizeConstraints(ImVec2(w, 0.0f), ImVec2(FLT_MAX, CalcMaxPopupHeightFromItemCount(popup_max_height_in_items) * it_anim2->second.open_anim));
        //SetNextWindowSizeConstraints(ImVec2(w2, 0.0f), ImVec2(FLT_MAX, CalcMaxPopupHeightFromItemCount(popup_max_height_in_items) * it_anim->second.open_anim));
    }

    // This is essentially a specialized version of BeginPopupEx()
    char name[16];
    ImFormatString(name, IM_ARRAYSIZE(name), "##Combo_%02d", g.BeginPopupStack.Size); // Recycle windows based on depth

    // Set position given a custom constraint (peak into expected window size so we can position it)
    // FIXME: This might be easier to express with an hypothetical SetNextWindowPosConstraints() function?
    // FIXME: This might be moved to Begin() or at least around the same spot where Tooltips and other Popups are calling FindBestWindowPosForPopupEx()?
    if (ImGuiWindow* popup_window = FindWindowByName(name))
        if (popup_window->WasActive)
        {
            // Always override 'AutoPosLastDirection' to not leave a chance for a past value to affect us.
            ImVec2 size_expected = CalcWindowNextAutoFitSize(popup_window);
            popup_window->AutoPosLastDirection = (flags & ImGuiComboFlags_PopupAlignLeft) ? ImGuiDir_Left : ImGuiDir_Down; // Left = "Below, Toward Left", Down = "Below, Toward Right (default)"
            ImRect r_outer = GetPopupAllowedExtentRect(popup_window);
            ImVec2 pos = FindBestWindowPosForPopupEx(bb.GetBL(), size_expected, &popup_window->AutoPosLastDirection, r_outer, bb, ImGuiPopupPositionPolicy_ComboBox);
            SetNextWindowPos(pos);
        }

    // We don't use BeginPopupEx() solely because we have a custom name string, which we could make an argument to BeginPopupEx()
    ImGuiWindowFlags window_flags = ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_Popup | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove;
    PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(8, 10)); // Horizontally align ourselves with the framed text
    PushStyleVar(ImGuiStyleVar_PopupRounding, 3.0f);
    PushStyleVar(ImGuiStyleVar_PopupBorderSize, 0.0f);
    PushStyleColor(ImGuiCol_PopupBg, ImVec4(ImColor(GetStyleColorVec4(ImGuiCol_Accent).x, GetStyleColorVec4(ImGuiCol_Accent).y, GetStyleColorVec4(ImGuiCol_Accent).z, it_anim3->second.selected_rect)));
    bool ret = Begin(name, NULL, window_flags | ImGuiWindowFlags_NoScrollbar);
    PopStyleVar(3);
    PopStyleColor();
    /*
    ImGuiWindowFlags window_flags = ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_Popup | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove;
    PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(g.Style.FramePadding.x, g.Style.WindowPadding.y)); // Horizontally align ourselves with the framed text
    bool ret = Begin(name, NULL, window_flags);
    PopStyleVar();*/
    if (!ret)
    {
        EndPopup();
        IM_ASSERT(0);   // This should never happen as we tested for IsPopupOpen() above
        return false;
    }
    return true;
    //return begin_combopopup(popup_id, bb, flags);
}

struct checkbox_state
{
    ImVec4 text;
    bool hovered = false;
};

namespace c_menu {
    bool tab_button(const char* label, const ImVec2& size_arg)
    {
        
    }

    void tab_line(const vector<string>& tab_names, int& current_tab)
    {
        
    }

    bool listbox(const char* label, int* current_item, const char* const items[], int items_count, int height_items)
    {
        const bool value_changed = listbox(label, current_item, Items_ArrayGetter, (void*)items, items_count, height_items);
        return value_changed;
    }

    bool listbox(const char* label, int* current_item, bool (*items_getter)(void*, int, const char**), void* data, int items_count, int height_in_items)
    {
        ImGuiContext& g = *GImGui;

        // Calculate size from "height_in_items"
        if (height_in_items < 0)
            height_in_items = ImMin(items_count, 7);
        float height_in_items_f = height_in_items + 0.25f;
        ImVec2 size(0.0f, ImFloor(GetTextLineHeightWithSpacing() * height_in_items_f + g.Style.FramePadding.y * 2.0f));

        if (!BeginListBox(label, size))
            return false;

        // Assume all items have even height (= 1 line of text). If you need items of different height,
        // you can create a custom version of ListBox() in your code without using the clipper.
        bool value_changed = false;
        ImGuiListClipper clipper;
        clipper.Begin(items_count, GetTextLineHeightWithSpacing()); // We know exactly our line height here so we pass it as a minor optimization, but generally you don't need to.
        while (clipper.Step())
            for (int i = clipper.DisplayStart; i < clipper.DisplayEnd; i++)
            {
                const char* item_text;
                if (!items_getter(data, i, &item_text))
                    item_text = "*Unknown item*";

                PushID(i);
                const bool item_selected = (i == *current_item);
                if (selectable(item_text, item_selected, 0, {0,0}))
                {
                    *current_item = i;
                    value_changed = true;
                }
                if (item_selected)
                    SetItemDefaultFocus();
                PopID();
            }
        EndListBox();

        if (value_changed)
            MarkItemEdited(g.LastItemData.ID);

        return value_changed;
    }

    bool button(const char* label, const ImVec2& size_arg, bool makeup)
    {
        return button_ex(label, size_arg, makeup, ImGuiButtonFlags_None);
    }

    bool buttonW(const char* label, const ImVec2& size_arg, bool makeup)
    {
        return button_wex(label, size_arg, makeup, ImGuiButtonFlags_None);
    }

    bool selectablee(const char* label, bool* p_selected, ImGuiSelectableFlags flags, const ImVec2& size_arg)
    {
        if (selectable(label, *p_selected, flags, size_arg))
        {
            *p_selected = !*p_selected;
            return true;
        }
        return false;
    }

    bool checkbox(const char* label, bool* v)
    {
        static std::map<bool*, float> anim22;
        anim22[v] = clerp(anim22[v], (float)*v, GImGui->IO.DeltaTime * 10);

        ImGuiWindow* window = GetCurrentWindow();
        if (window->SkipItems)
            return false;

        ImGuiContext& g = *GImGui;
        const ImGuiStyle& style = g.Style;
        const ImGuiID id = window->GetID(label);
        const ImVec2 label_size = CalcTextSize(label, NULL, true);

        const float w = CalcItemWidth();

        const float square_sz = (label_size.y + style.FramePadding.y)*1.1;
        const ImVec2 pos = window->DC.CursorPos;
        const ImRect total_bb(pos, pos + ImVec2(square_sz + (label_size.x > 0.0f ? style.ItemInnerSpacing.x + label_size.x : 0.0f), square_sz));
        ItemSize(total_bb, style.FramePadding.y);
        if (!ItemAdd(total_bb, id))
        {
            IMGUI_TEST_ENGINE_ITEM_INFO(id, label, g.LastItemData.StatusFlags | ImGuiItemStatusFlags_Checkable | (*v ? ImGuiItemStatusFlags_Checked : 0));
            return false;
        }

        bool hovered, held;
        const ImRect check_bb(pos, pos + ImVec2(square_sz, square_sz));
        bool pressed = ButtonBehavior(total_bb, id, &hovered, &held);
        if (pressed)
        {
            *v = !(*v);
            MarkItemEdited(id);
        }
        const float pad = ImMax(1.0f, IM_FLOOR(square_sz / 3.0f));
        const float pad2 = square_sz / 4;

        static std::map <ImGuiID, wdg_element> anim;
        auto it_anim = anim.find(id);
        if (it_anim == anim.end())
        {
            anim.insert({ id, { 0.0f } });
            it_anim = anim.find(id);
        }

        it_anim->second.selected_rect = ImLerp(it_anim->second.selected_rect, *v ? g.Style.Alpha : (hovered ? (g.Style.Alpha / 5) : 0.0f), 0.08f * (1.0f - ImGui::GetIO().DeltaTime));

        window->DrawList->AddRectFilled(total_bb.Min, total_bb.Min + ImVec2(square_sz, square_sz), ImColor(GetStyleColorVec4(ImGuiCol_WindowBg).x, GetStyleColorVec4(ImGuiCol_WindowBg).y, GetStyleColorVec4(ImGuiCol_WindowBg).z, g.Style.Alpha), ImGui::GetStyle().FrameRounding);

        window->DrawList->AddRectFilled(total_bb.Min, total_bb.Min + ImVec2(square_sz, square_sz), ImColor(GetStyleColorVec4(ImGuiCol_Accent).x, GetStyleColorVec4(ImGuiCol_Accent).y, GetStyleColorVec4(ImGuiCol_Accent).z, it_anim->second.selected_rect), ImGui::GetStyle().FrameRounding);

        it_anim->second.checkmark = ImLerp(it_anim->second.checkmark, *v ? ImColor(0, 0, 0, (int)(style.Alpha * 255)) : ImColor(0.f, 0.f, 0.f, 0.f), g.IO.DeltaTime * 6.f);
        ImGui::RenderCheckMark(window->DrawList, check_bb.Min + ImVec2(pad, pad) + ImVec2(square_sz / 2, square_sz / 2) * (1.0f - anim22[v]), ImColor(it_anim->second.checkmark), (square_sz - pad * 2.0f) * anim22[v]);

        //AddRadialGradient(window->DrawList, check_bb.Min + ImVec2(pad2, pad2), 28, ImColor(154/255.f,151/255.f,199/255.f, anim22[v]/4), ImColor(154/255.f,151/255.f,199/255.f, 0.f));

        ImVec2 label_pos = ImVec2(check_bb.Max.x + style.ItemInnerSpacing.x, check_bb.Min.y + style.FramePadding.y / 2);

        static std::map<ImGuiID, checkbox_state> anim223;
        auto it_anim2 = anim223.find(id);
        if (it_anim2 == anim223.end())
        {
            anim223.insert({ id, checkbox_state() });
            it_anim2 = anim223.find(id);
        }

        bool hoveredAndChanged = hovered || *v;

        it_anim2->second.text = ImLerp(it_anim2->second.text, hoveredAndChanged ? ImColor(255, 255, 255, (int)(style.Alpha * 255)) : ImColor(160, 160, 160, (int)(style.Alpha * 255)), g.IO.DeltaTime * 6.f);

        if (label_size.x > 0.0f)
            rendertext(it_anim2->second.text, label_pos, label, NULL, true);

        IMGUI_TEST_ENGINE_ITEM_INFO(id, label, g.LastItemData.StatusFlags | ImGuiItemStatusFlags_Checkable | (*v ? ImGuiItemStatusFlags_Checked : 0));
        return pressed;
    }

    bool slider_int(const char* label, int* v, int v_min, int v_max, const char* format, ImGuiSliderFlags flags)
    {
        return slider_scalar(label, ImGuiDataType_S32, v, &v_min, &v_max, format, flags);
    }

    bool slider_float(const char* label, float* v, float v_min, float v_max, const char* format, ImGuiSliderFlags flags)
    {
        return slider_scalar(label, ImGuiDataType_Float, v, &v_min, &v_max, format, flags);
    }

    bool combo(const char* label, int* current_item, bool (*items_getter)(void*, int, const char**), void* data, int items_count, int popup_max_height_in_items)
    {
        ImGuiContext& g = *GImGui;

        // Call the getter to obtain the preview string which is a parameter to BeginCombo()
        const char* preview_value = NULL;
        if (*current_item >= 0 && *current_item < items_count)
            items_getter(data, *current_item, &preview_value);

        // The old Combo() API exposed "popup_max_height_in_items". The new more general BeginCombo() API doesn't have/need it, but we emulate it here.
        if (popup_max_height_in_items != -1 && !(g.NextWindowData.Flags & ImGuiNextWindowDataFlags_HasSizeConstraint))
            SetNextWindowSizeConstraints(ImVec2(0, 0), ImVec2(FLT_MAX, CalcMaxPopupHeightFromItemCount(popup_max_height_in_items)));

        if (!begin_combo(label, preview_value, ImGuiComboFlags_None))
            return false;

        // Display items
        // FIXME-OPT: Use clipper (but we need to disable it on the appearing frame to make sure our call to SetItemDefaultFocus() is processed)
        bool value_changed = false;
        for (int i = 0; i < items_count; i++)
        {
            PushID(i);
            const bool item_selected = (i == *current_item);
            const char* item_text;
            if (!items_getter(data, i, &item_text))
                item_text = "*Unknown item*";
            if (selectable(item_text, item_selected, 0, { 0,0 }))
            {
                value_changed = true;
                *current_item = i;
            }
            if (item_selected)
                SetItemDefaultFocus();
            PopID();
        }

        EndCombo();

        if (value_changed)
            MarkItemEdited(g.LastItemData.ID);

        return value_changed;
    }

    
    // Combo box helper allowing to pass an array of strings.
    bool combo(const char* label, int* current_item, const char* const items[], int items_count, int height_in_items)
    {
        return combo(label, current_item, Items_ArrayGetter, (void*)items, items_count, height_in_items);
    }

    bool begin_child(float point, const char* str_id, const ImVec2& size, ImGuiWindowFlags flags, bool cringy_thingy)
    {
        ImGuiWindow* window = GetCurrentWindow();
        
    }
}
