//
// Created by rei on 12/19/23.
//

#ifndef WIDGETS_HPP
#define WIDGETS_HPP

#include "imgui_internal.h"
#include <string>
#include <vector>

namespace c_menu {
    auto tab_line(const std::vector<std::string>& tab_names, int& current_tab) -> void;
    auto listbox(const char* label, int* current_item, const char* const items[], int items_count, int height_in_items = -1) -> bool;
    auto listbox(const char* label, int* current_item, bool (*items_getter)(void* data, int idx, const char** out_text), void* data, int items_count, int height_in_items = -1) -> bool;
    auto begin_child(float point, const char* str_id, const ImVec2& size = ImVec2(0, 0), ImGuiWindowFlags flags = 0, bool cringy_thingy = false) -> bool;
    auto checkbox(const char* label, bool* v) -> bool;
    auto colorcheckbox(const char* label, bool* v, ImVec4 &color) -> bool;
    auto colorcheckbox2(const char* label, bool* v, ImVec4 &color, ImVec4 &color2) -> bool;
    auto colorcheckbox3(const char* label, bool* v, ImVec4 &color, ImVec4 &color2, ImVec4 &color3) -> bool;
    auto slider_int(const char* label, int* v, int v_min, int v_max, const char* format = "%d", ImGuiSliderFlags flags = 0) -> bool;
    auto slider_float(const char* label, float* v, float v_min, float v_max, const char* format = "%.3f", ImGuiSliderFlags flags = 0) -> bool;
    auto combo(const char* label, int* current_item, bool(*items_getter)(void*, int, const char**), void* data, int items_count, int popup_max_height_in_items = -1) -> bool;
    auto combo(const char* label, int* current_item, const char* const items[], int items_count, int popup_max_height_in_items = -1) -> bool;
    auto button(const char* label, const ImVec2& size_arg = ImVec2(0, 0), bool makeup = true) -> bool;
    auto buttonW(const char* label, const ImVec2& size_arg = ImVec2(0, 0), bool makeup = true) -> bool;
    auto selectablee(const char* label, bool* p_selected, ImGuiSelectableFlags flags = 0, const ImVec2& size_arg = { 0,0 }) -> bool;
}

#endif //WIDGETS_HPP
