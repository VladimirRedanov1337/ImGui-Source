//
// Created by rei on 12/18/2023.
//

#include "imgui_wrapper.hpp"
#include <vector>

static inline ImVec2  operator*(const ImVec2& lhs, const float rhs) { return ImVec2(lhs.x * rhs, lhs.y * rhs); }
static inline ImVec2  operator/(const ImVec2& lhs, const float rhs) { return ImVec2(lhs.x / rhs, lhs.y / rhs); }
static inline ImVec2  operator+(const ImVec2& lhs, const float rhs) { return ImVec2(lhs.x + rhs, lhs.y + rhs); }
static inline ImVec2  operator+(const ImVec2& lhs, const ImVec2& rhs) { return ImVec2(lhs.x + rhs.x, lhs.y + rhs.y); }
static inline ImVec2  operator-(const ImVec2& lhs, const ImVec2& rhs) { return ImVec2(lhs.x - rhs.x, lhs.y - rhs.y); }
static inline ImVec2  operator-(const ImVec2& lhs, const float rhs) { return ImVec2(lhs.x - rhs, lhs.y - rhs); }
static inline ImVec2  operator*(const ImVec2& lhs, const ImVec2& rhs) { return ImVec2(lhs.x * rhs.x, lhs.y * rhs.y); }
static inline ImVec2  operator/(const ImVec2& lhs, const ImVec2& rhs) { return ImVec2(lhs.x / rhs.x, lhs.y / rhs.y); }
static inline ImVec2& operator*=(ImVec2& lhs, const float rhs) { lhs.x *= rhs; lhs.y *= rhs; return lhs; }
static inline ImVec2& operator/=(ImVec2& lhs, const float rhs) { lhs.x /= rhs; lhs.y /= rhs; return lhs; }
static inline ImVec2& operator+=(ImVec2& lhs, const ImVec2& rhs) { lhs.x += rhs.x; lhs.y += rhs.y; return lhs; }
static inline ImVec2& operator-=(ImVec2& lhs, const ImVec2& rhs) { lhs.x -= rhs.x; lhs.y -= rhs.y; return lhs; }
static inline ImVec2& operator*=(ImVec2& lhs, const ImVec2& rhs) { lhs.x *= rhs.x; lhs.y *= rhs.y; return lhs; }
static inline ImVec2& operator/=(ImVec2& lhs, const ImVec2& rhs) { lhs.x /= rhs.x; lhs.y /= rhs.y; return lhs; }
static inline ImVec4  operator+(const ImVec4& lhs, const ImVec4& rhs) { return ImVec4(lhs.x + rhs.x, lhs.y + rhs.y, lhs.z + rhs.z, lhs.w + rhs.w); }
static inline ImVec4  operator-(const ImVec4& lhs, const ImVec4& rhs) { return ImVec4(lhs.x - rhs.x, lhs.y - rhs.y, lhs.z - rhs.z, lhs.w - rhs.w); }
static inline ImVec4  operator*(const ImVec4& lhs, const ImVec4& rhs) { return ImVec4(lhs.x * rhs.x, lhs.y * rhs.y, lhs.z * rhs.z, lhs.w * rhs.w); }

#pragma region imgui_wrapper
namespace _imgui {
	auto add_text(ImDrawList* drawlist, bool shadow, bool outline, const ImVec2& pos, ImColor color, const char* value, ImColor outlinecolor) -> void {
        const static std::vector<ImVec2> text_offsets {
                {1*ImGui::GetIO().FontGlobalScale, 1*ImGui::GetIO().FontGlobalScale},
                {-1*ImGui::GetIO().FontGlobalScale, -1*ImGui::GetIO().FontGlobalScale},
                {0, 1*ImGui::GetIO().FontGlobalScale},
                {0, -1*ImGui::GetIO().FontGlobalScale},
                {1*ImGui::GetIO().FontGlobalScale, 1*ImGui::GetIO().FontGlobalScale},
                {-1*ImGui::GetIO().FontGlobalScale, -1*ImGui::GetIO().FontGlobalScale},
                {-1*ImGui::GetIO().FontGlobalScale, 1*ImGui::GetIO().FontGlobalScale},
                {1*ImGui::GetIO().FontGlobalScale, -1*ImGui::GetIO().FontGlobalScale},
                {1*ImGui::GetIO().FontGlobalScale, 0},
                {-1*ImGui::GetIO().FontGlobalScale, 0},
                {0, 1*ImGui::GetIO().FontGlobalScale},
                {0, -1*ImGui::GetIO().FontGlobalScale}
        };
        if (outline) {
            for (auto text_offset: text_offsets) {
                drawlist->AddText({pos.x+text_offset.x, pos.y+text_offset.y}, ImColor(outlinecolor.Value.x, outlinecolor.Value.y, outlinecolor.Value.z, color.Value.w), value);
            }
        }
        if (shadow) drawlist->AddText({ pos.x + 2*ImGui::GetIO().FontGlobalScale, pos.y + 2*ImGui::GetIO().FontGlobalScale }, ImColor(5, 5, 5, (int)float(color.Value.w * 160)), value);
        drawlist->AddText(pos, color, value);
    }
    auto window(const char* name, const ImVec2& size, const ImVec2& pos, ImGuiCond cond, bool* v, ImGuiWindowFlags flags) -> bool {
        if (pos.x != -1 && pos.y != -1) ImGui::SetNextWindowPos(pos, cond);
        if (size.x != -1 && size.y != -1) ImGui::SetNextWindowSize(size, cond);
        return ImGui::Begin(name, v, flags);
    }

    auto end() -> void {
        return ImGui::End();
    }

    auto set_cursor(const ImVec2& pos) -> void {
        return ImGui::SetCursorPos(pos);
    }

    auto getio() -> ImGuiIO {
        ImGuiIO &io = ImGui::GetIO();
        return io;
    }

    auto button(const char* name, bool invisible, const ImVec2& size) -> bool {
        bool sizevalid = size.x != -1 && size.y != -1;
        ImVec2 _size = sizevalid ? size : ImVec2(0, 0);
        return invisible ? ImGui::InvisibleButton(name, _size) : ImGui::Button(name, _size);
    }

    auto push_style(ImGuiStyleVar var, const ImVec2& v) -> void {
        return ImGui::PushStyleVar(var, v);
    }

    auto push_style(ImGuiStyleVar var, float v) -> void {
        return ImGui::PushStyleVar(var, v);
    }

    auto pop_style(int quantity) -> void {
        return ImGui::PopStyleVar(quantity);
    }

    auto window_size() -> ImVec2 {
        return ImGui::GetWindowSize();
    }
    
    auto get_avail() -> ImVec2 {
    	return ImGui::GetContentRegionAvail();
    }
}

#pragma endregion