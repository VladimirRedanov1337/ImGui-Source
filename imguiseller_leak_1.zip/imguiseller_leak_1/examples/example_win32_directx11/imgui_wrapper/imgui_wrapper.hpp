//
// Created by rei on 12/18/2023.
//

#ifndef IMGUIWRAPPER_HPP
#define IMGUIWRAPPER_HPP

#define IMGUI_DEFINE_MATG_OPERATORS

#include "imgui_internal.h"
#include "imgui.h"
#include <GLES2/gl2.h>
#include <string>

namespace _imgui {
	auto add_text(ImDrawList* drawlist, bool shadow, bool outline, const ImVec2& pos, ImColor color, const char* value, ImColor outlinecolor = ImColor(0, 0, 0)) -> void;
    auto window(const char* name, const ImVec2& size = {-1, -1}, const ImVec2& pos = {-1, -1}, ImGuiCond cond = ImGuiCond_Once, bool* v = nullptr, ImGuiWindowFlags flags = 0) -> bool;
    auto end() -> void;
    auto set_cursor(const ImVec2& pos) -> void;
    auto getio() -> ImGuiIO;
    auto button(const char* name, bool invisible = false, const ImVec2& size = {-1, -1}) -> bool;
    auto push_style(ImGuiStyleVar var, float v) -> void;
    auto push_style(ImGuiStyleVar var, const ImVec2& v) -> void;
    auto pop_style(int quantity = 1) -> void;
    auto get_avail() -> ImVec2;
    auto window_size() -> ImVec2;
};

#endif //IMGUIWRAPPER_HPP
